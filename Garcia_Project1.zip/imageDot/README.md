# ImagePixeler
This processing program breaks an image down into quadrants of average colors that get smaller when hovered over. (PC and Android)

PC:
Open the imageDot.pde
Ensure that the top right corner is set to Java
Press the run button

Android:
Open the imageDot.pde
Connect your android device and make sure developer mode is enabled, your device should appear under Android>Devices if connected
Ensure that the top right corner is set to Android
Press the run button
The application is now installed on your device

Add Image:
Add the image file to the data folder
In the data folder open images.txt add the name of the image on a new line

Controls:
Press on an image to select it
Press the BACKSPACE button on PC or the back button on Android in order to return to the Selection page
